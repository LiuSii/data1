CREATE VIEW orderview AS
  SELECT
    `shoppingonline`.`order`.`order_id`        AS `order_id`,
    `shoppingonline`.`order`.`goods_id`        AS `goods_id`,
    `shoppingonline`.`order`.`store_id`        AS `store_id`,
    `shoppingonline`.`order`.`user_id`         AS `user_id`,
    `shoppingonline`.`order`.`order_amount`    AS `order_amount`,
    `shoppingonline`.`order`.`order_price`     AS `order_price`,
    `shoppingonline`.`order`.`order_status`    AS `order_status`,
    `shoppingonline`.`order`.`order_timeToPay` AS `order_timeToPay`,
    `shoppingonline`.`order`.`order_timeToGet` AS `order_timeToGet`,
    `shoppingonline`.`user`.`user_name`        AS `user_name`,
    `shoppingonline`.`user`.`user_phone`       AS `user_phone`,
    `shoppingonline`.`user`.`user_address`     AS `user_address`,
    `shoppingonline`.`store`.`store_name`      AS `store_name`,
    `shoppingonline`.`goods`.`goods_name`      AS `goods_name`
  FROM (((`shoppingonline`.`order`
    JOIN `shoppingonline`.`user` ON ((`shoppingonline`.`order`.`user_id` = `shoppingonline`.`user`.`user_id`))) JOIN
    `shoppingonline`.`store` ON ((`shoppingonline`.`order`.`store_id` = `shoppingonline`.`store`.`store_id`))) JOIN
    `shoppingonline`.`goods` ON ((`shoppingonline`.`order`.`goods_id` = `shoppingonline`.`goods`.`goods_id`)));
